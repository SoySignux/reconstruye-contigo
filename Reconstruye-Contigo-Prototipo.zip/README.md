# Reconstruye Contigo

Aplicación web de demostración para organizar la recuperación de una vivienda después de un incendio. Basada en el pitch y la propuesta de valor de Los Geoinformáticos.

## Abrir la aplicación

Puedes abrir `index.html` directamente en Chrome o Edge. Para una vista local con dirección web, instala Node.js si no lo tienes y ejecuta en esta carpeta:

```sh
npm start
```

Abre **http://localhost:4173**. No necesitas instalar paquetes ni ejecutar un proceso de compilación. Para detener el servidor, usa `Ctrl+C`.

## Funciones

- **Inicio:** resumen de gestiones, progreso calculado y próximos pasos.
- **Ayudas:** seis fichas ilustrativas, búsqueda, filtros por categoría, favoritos y creación de gestiones desde una ficha.
- **Planificación:** agenda semanal, navegación entre semanas, registro y edición de turnos, tareas por agendar y detección de cruces entre turnos y gestiones.
- **Seguimiento:** creación, edición y eliminación de gestiones; estados pendiente, en proceso y completada; observaciones y búsqueda.
- **Perfil:** cambio de nombre y localidad, exportación de datos en JSON y restablecimiento de los ejemplos.
- Diseño adaptable a celular, tablet y computador, navegación por teclado y ventanas de diálogo accesibles.

Las tareas y los turnos de ejemplo se ubican respecto del día en que se abre la aplicación por primera vez. Después conservan sus fechas. Restablecer la demostración vuelve a crearlos respecto del día actual.

## Publicar en GitHub Pages

1. Crea un repositorio público en GitHub, por ejemplo `reconstruye-contigo`.
2. Sube el contenido de esta carpeta a la raíz del repositorio. `index.html` debe quedar directamente en la raíz, no dentro de una carpeta adicional. Conserva la carpeta `assets` y el archivo `.nojekyll`.
3. En el repositorio, entra a **Settings → Pages**.
4. En **Build and deployment → Source**, elige **Deploy from a branch**.
5. Selecciona la rama **main**, carpeta **/(root)**, y pulsa **Save**.
6. Espera la publicación. GitHub mostrará la dirección, normalmente `https://TU-USUARIO.github.io/reconstruye-contigo/`.

No debes configurar claves, variables de entorno, una base de datos ni GitHub Actions. La navegación usa fragmentos como `#ayudas`, por lo que recargar una pantalla también funciona bajo la ruta del repositorio.

Guía oficial consultada: [Configurar una fuente de publicación en GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

Para cualquier otro hosting estático, sube `index.html`, `styles.css`, `app.js` y la carpeta `assets` al directorio público. `package.json` y `scripts` solo sirven para la vista local.

## Recorrido sugerido para presentar

1. Muestra **Inicio** con el perfil ficticio de Leonardo y el resumen de sus seis gestiones.
2. En **Ayudas**, abre “Alojamiento temporal” y pulsa “Añadir a mis gestiones”.
3. Elige una fecha y una hora fuera del turno de trabajo, escribe una observación y guarda.
4. En **Planificación**, selecciona ese día para mostrar la nueva gestión junto a los turnos.
5. En **Seguimiento**, cambia la gestión a “En proceso” y luego a “Completada”.
6. Vuelve a **Inicio** para mostrar que el porcentaje se actualizó. Recarga la página para demostrar que el avance se conserva.

Desde el botón de ayuda o el perfil puedes restablecer la demostración antes de otra presentación.

## Alcance del prototipo

Este es un prototipo académico funcional en el navegador. Las fichas, apoyos e instituciones son ilustrativos: no constituyen información oficial ni confirman requisitos o beneficios. La aplicación no tiene conexiones institucionales, postulaciones reales, cuentas, avisos automáticos ni seguimiento real de obras. El porcentaje representa las tareas completadas por el usuario.

Los datos se guardan en `localStorage`, bajo la clave `reconstruye-contigo-v1`, exclusivamente en el navegador y origen usados. Otro dispositivo o una dirección distinta tendrá datos independientes. Borrar los datos del sitio elimina ese progreso. Si el almacenamiento está bloqueado, se muestra un aviso y los cambios duran solo durante la sesión. Usa datos ficticios para presentar el prototipo.

La exportación JSON permite conservar una copia legible; esta versión no incluye importación. Las tipografías DM Sans y Manrope se solicitan a Google Fonts; si no hay conexión, la interfaz utiliza la fuente disponible en el dispositivo. Las ilustraciones y los iconos son archivos o trazados locales.

## Archivos

```text
index.html                 Entrada de la aplicación
styles.css                 Diseño y adaptación a distintos tamaños
app.js                     Pantallas, datos de ejemplo y lógica
assets/                    Icono e ilustración SVG
scripts/serve.cjs           Servidor para vista previa local
package.json               Comandos locales, sin dependencias
.nojekyll                  Publicación estática en GitHub Pages
```

Para comprobar la sintaxis de JavaScript:

```sh
npm run check
```
